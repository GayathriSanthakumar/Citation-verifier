## Packages
recharts | For the citation breakdown pie chart
framer-motion | For smooth page transitions and beautiful loading animations
lucide-react | Academic and UI icons

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  serif: ["var(--font-serif)"],
}

The API endpoints expect standard JSON payloads. The paper upload might take a long time due to AI processing, so the frontend includes a polished, extended loading state.
