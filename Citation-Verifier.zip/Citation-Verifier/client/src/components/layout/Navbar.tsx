import { Link, useLocation } from "wouter";
import { BookOpenCheck } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2 group transition-opacity hover:opacity-80">
              <div className="bg-primary text-primary-foreground p-1.5 rounded-lg shadow-sm group-hover:shadow-md transition-shadow">
                <BookOpenCheck className="w-5 h-5" />
              </div>
              <span className="font-serif text-xl font-bold text-primary tracking-tight">
                ScholarTrust
              </span>
            </Link>
          </div>
          
          <div className="flex items-center gap-6">
            <Link 
              href="/dashboard" 
              className={`text-sm font-medium transition-colors hover:text-primary ${
                location === '/dashboard' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Dashboard
            </Link>
            <Link href="/dashboard" className="hidden sm:flex">
              <button className="bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-medium px-5 py-2.5 rounded-full shadow-sm hover:shadow transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0">
                Verify Paper
              </button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
