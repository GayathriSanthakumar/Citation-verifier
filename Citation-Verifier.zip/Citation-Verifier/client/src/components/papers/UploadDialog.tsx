import { useState } from "react";
import { useLocation } from "wouter";
import { useUploadPaper } from "@/hooks/use-papers";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { FileText, Loader2, Sparkles, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function UploadDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const { mutate: uploadPaper, isPending } = useUploadPaper();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      toast({
        title: "Missing fields",
        description: "Please provide both a title and the paper content.",
        variant: "destructive"
      });
      return;
    }

    uploadPaper(
      { title, content },
      {
        onSuccess: (data) => {
          toast({
            title: "Analysis Complete",
            description: "Your paper has been verified successfully.",
          });
          onOpenChange(false);
          setTitle("");
          setContent("");
          setLocation(`/paper/${data.id}`);
        },
        onError: (err) => {
          toast({
            title: "Analysis Failed",
            description: err.message,
            variant: "destructive"
          });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={isPending ? undefined : onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden border-0 shadow-2xl rounded-2xl">
        <AnimatePresence mode="wait">
          {!isPending ? (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-6 sm:p-8 bg-background"
            >
              <DialogHeader className="mb-6">
                <DialogTitle className="font-serif text-2xl text-foreground flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  Verify New Paper
                </DialogTitle>
                <DialogDescription className="text-muted-foreground text-sm mt-1">
                  Paste your academic text below. Our AI will extract and verify every citation against the Crossref database and contextually analyze support logic.
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleUpload} className="space-y-5">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-semibold text-foreground">
                    Paper Title
                  </label>
                  <input
                    id="title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. The Impact of Quantum Computing on Cryptography"
                    className="w-full px-4 py-3 rounded-xl bg-muted/30 border border-border text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="content" className="text-sm font-semibold text-foreground">
                    Paper Content (Text)
                  </label>
                  <textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Paste the full text of your paper here, including references..."
                    className="w-full h-48 px-4 py-3 rounded-xl bg-muted/30 border border-border text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all resize-none"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => onOpenChange(false)}
                    className="px-5 py-2.5 rounded-full font-medium text-muted-foreground hover:bg-muted/50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!title.trim() || !content.trim()}
                    className="px-6 py-2.5 rounded-full font-medium bg-primary text-primary-foreground shadow-md hover:shadow-lg hover:bg-primary/90 hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none transition-all flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    Begin Analysis
                  </button>
                </div>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="loading"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-12 bg-gradient-to-br from-primary/5 to-primary/10 flex flex-col items-center justify-center text-center space-y-6 h-[460px]"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse" />
                <div className="bg-white p-4 rounded-2xl shadow-xl relative">
                  <Loader2 className="w-10 h-10 text-primary animate-spin" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="font-serif text-2xl font-semibold text-foreground">Analyzing Citations...</h3>
                <p className="text-muted-foreground max-w-[280px] mx-auto text-sm leading-relaxed">
                  Extracting references, querying Crossref, and validating contextual claims. This may take a minute.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-medium text-amber-600 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200/50">
                <AlertCircle className="w-3.5 h-3.5" />
                Please do not close this window
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
