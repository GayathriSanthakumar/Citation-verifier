import { motion } from "framer-motion";

export function ScoreBadge({ score, size = "md" }: { score: number; size?: "sm" | "md" | "lg" }) {
  // Determine color based on score
  let colorClass = "text-emerald-500";
  let bgClass = "bg-emerald-50";
  let borderClass = "border-emerald-200";
  let glowClass = "shadow-emerald-500/20";
  
  if (score < 50) {
    colorClass = "text-rose-500";
    bgClass = "bg-rose-50";
    borderClass = "border-rose-200";
    glowClass = "shadow-rose-500/20";
  } else if (score < 80) {
    colorClass = "text-amber-500";
    bgClass = "bg-amber-50";
    borderClass = "border-amber-200";
    glowClass = "shadow-amber-500/20";
  }

  const sizes = {
    sm: "w-12 h-12 text-lg border-2",
    md: "w-20 h-20 text-3xl border-[3px]",
    lg: "w-32 h-32 text-5xl border-4"
  };

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 100, damping: 15 }}
      className={`relative rounded-full flex items-center justify-center font-serif font-bold shadow-xl ${glowClass} ${bgClass} ${colorClass} ${borderClass} ${sizes[size]}`}
    >
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/60 to-transparent mix-blend-overlay" />
      <span className="relative z-10">{score}</span>
      {size === "lg" && <span className="absolute -bottom-2 text-xs font-sans font-medium text-muted-foreground uppercase tracking-widest bg-background px-2">Score</span>}
    </motion.div>
  );
}
