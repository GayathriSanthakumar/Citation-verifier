import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, CheckCircle2, AlertTriangle, XCircle, Info } from "lucide-react";
import type { CitationResponse } from "@shared/routes";

export function CitationTable({ citations }: { citations: CitationResponse[] }) {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const getStatusIcon = (classification: string) => {
    switch (classification) {
      case "Verified": return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      case "Weak Support": return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case "Hallucinated": return <XCircle className="w-5 h-5 text-rose-500" />;
      case "Padding": return <Info className="w-5 h-5 text-slate-400" />;
      default: return <Info className="w-5 h-5 text-slate-400" />;
    }
  };

  const getStatusBadge = (classification: string) => {
    const base = "px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap border";
    switch (classification) {
      case "Verified": return `${base} bg-emerald-50 text-emerald-700 border-emerald-200`;
      case "Weak Support": return `${base} bg-amber-50 text-amber-700 border-amber-200`;
      case "Hallucinated": return `${base} bg-rose-50 text-rose-700 border-rose-200`;
      case "Padding": return `${base} bg-slate-50 text-slate-600 border-slate-200`;
      default: return `${base} bg-muted text-muted-foreground border-border`;
    }
  };

  if (!citations || citations.length === 0) {
    return (
      <div className="p-8 text-center bg-muted/20 rounded-2xl border border-dashed border-border/60">
        <p className="text-muted-foreground">No citations found in this paper.</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="rounded-2xl border border-border/60 bg-card overflow-hidden shadow-sm">
        <div className="grid grid-cols-12 gap-4 p-4 bg-muted/30 border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          <div className="col-span-6 sm:col-span-5">Citation Text</div>
          <div className="col-span-4 sm:col-span-3 text-center">Classification</div>
          <div className="hidden sm:block sm:col-span-3 text-center">Score Breakdown</div>
          <div className="col-span-2 sm:col-span-1 text-right">Details</div>
        </div>
        
        <div className="divide-y divide-border/50">
          {citations.map((citation) => (
            <div key={citation.id} className="group">
              <div 
                onClick={() => setExpandedId(expandedId === citation.id ? null : citation.id)}
                className="grid grid-cols-12 gap-4 p-4 items-center cursor-pointer hover:bg-muted/10 transition-colors"
              >
                <div className="col-span-6 sm:col-span-5 flex items-start gap-3">
                  <div className="mt-0.5 flex-shrink-0">
                    {getStatusIcon(citation.classification)}
                  </div>
                  <p className="text-sm font-medium text-foreground line-clamp-2 leading-relaxed">
                    "{citation.text}"
                  </p>
                </div>
                
                <div className="col-span-4 sm:col-span-3 flex justify-center">
                  <span className={getStatusBadge(citation.classification)}>
                    {citation.classification}
                  </span>
                </div>
                
                <div className="hidden sm:flex sm:col-span-3 justify-center items-center gap-3 text-xs">
                  <div className="flex flex-col items-center">
                    <span className="font-semibold text-foreground">{citation.existenceScore}%</span>
                    <span className="text-[10px] text-muted-foreground uppercase">Exist</span>
                  </div>
                  <div className="w-px h-6 bg-border"></div>
                  <div className="flex flex-col items-center">
                    <span className="font-semibold text-foreground">{citation.accuracyScore}%</span>
                    <span className="text-[10px] text-muted-foreground uppercase">Accur</span>
                  </div>
                </div>
                
                <div className="col-span-2 sm:col-span-1 flex justify-end">
                  <button className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors">
                    <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${expandedId === citation.id ? "rotate-180" : ""}`} />
                  </button>
                </div>
              </div>
              
              <AnimatePresence>
                {expandedId === citation.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden bg-muted/10 border-t border-border/50 shadow-inner"
                  >
                    <div className="p-6">
                      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">Extracted Claim</h4>
                          <div className="p-4 bg-background rounded-xl border border-border/50 text-sm leading-relaxed text-foreground shadow-sm">
                            {citation.text}
                          </div>
                        </div>
                        
                        <div className="space-y-5">
                          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">Analysis Metrics</h4>
                          
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between mb-1.5 text-xs font-medium">
                                <span className="text-foreground">Existence (Crossref API)</span>
                                <span className={citation.existenceScore > 80 ? "text-emerald-600" : "text-amber-600"}>{citation.existenceScore}/100</span>
                              </div>
                              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${citation.existenceScore > 80 ? "bg-emerald-500" : "bg-amber-500"}`}
                                  style={{ width: `${citation.existenceScore}%` }}
                                />
                              </div>
                            </div>
                            
                            <div>
                              <div className="flex justify-between mb-1.5 text-xs font-medium">
                                <span className="text-foreground">Accuracy (Abstract Support)</span>
                                <span className={citation.accuracyScore > 80 ? "text-emerald-600" : "text-rose-600"}>{citation.accuracyScore}/100</span>
                              </div>
                              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${citation.accuracyScore > 80 ? "bg-emerald-500" : citation.accuracyScore > 40 ? "bg-amber-500" : "bg-rose-500"}`}
                                  style={{ width: `${citation.accuracyScore}%` }}
                                />
                              </div>
                            </div>

                            <div>
                              <div className="flex justify-between mb-1.5 text-xs font-medium">
                                <span className="text-foreground">Necessity (Contextual Need)</span>
                                <span className="text-foreground">{citation.necessityScore}/100</span>
                              </div>
                              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                                <div 
                                  className="h-full rounded-full bg-primary"
                                  style={{ width: `${citation.necessityScore}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
