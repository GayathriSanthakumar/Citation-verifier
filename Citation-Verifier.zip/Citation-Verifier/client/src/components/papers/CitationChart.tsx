import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import type { CitationResponse } from "@shared/routes";

const COLORS = {
  "Verified": "hsl(var(--chart-1))",
  "Weak Support": "hsl(var(--chart-2))",
  "Hallucinated": "hsl(var(--chart-3))",
  "Padding": "hsl(var(--chart-4))",
};

export function CitationChart({ citations }: { citations: CitationResponse[] }) {
  if (!citations || citations.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-muted/10 rounded-2xl border border-dashed">
        <p className="text-muted-foreground text-sm">No citations available to chart</p>
      </div>
    );
  }

  // Aggregate data
  const grouped = citations.reduce((acc, curr) => {
    acc[curr.classification] = (acc[curr.classification] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const data = Object.entries(grouped).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="h-64 w-full relative">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            stroke="none"
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={COLORS[entry.name as keyof typeof COLORS] || COLORS["Padding"]} 
                className="hover:opacity-80 transition-opacity outline-none"
              />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ 
              borderRadius: '12px', 
              border: '1px solid hsl(var(--border))',
              boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
              fontFamily: 'var(--font-sans)',
              fontSize: '13px',
              fontWeight: 500
            }}
            itemStyle={{ color: 'hsl(var(--foreground))' }}
          />
          <Legend 
            verticalAlign="bottom" 
            height={36}
            iconType="circle"
            wrapperStyle={{ fontSize: '12px', fontWeight: 500, color: 'hsl(var(--muted-foreground))' }}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="text-center pb-6">
          <span className="block text-2xl font-serif font-bold text-foreground">{citations.length}</span>
          <span className="block text-[10px] uppercase tracking-wider text-muted-foreground">Total</span>
        </div>
      </div>
    </div>
  );
}
