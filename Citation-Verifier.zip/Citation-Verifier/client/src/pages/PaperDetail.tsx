import { useRoute } from "wouter";
import { Link } from "wouter";
import { ArrowLeft, ExternalLink, Calendar, FileText, Download } from "lucide-react";
import { format } from "date-fns";
import { Navbar } from "@/components/layout/Navbar";
import { usePaper } from "@/hooks/use-papers";
import { ScoreBadge } from "@/components/papers/ScoreBadge";
import { CitationChart } from "@/components/papers/CitationChart";
import { CitationTable } from "@/components/papers/CitationTable";

export function PaperDetail() {
  const [, params] = useRoute("/paper/:id");
  const paperId = params?.id ? parseInt(params.id) : 0;
  
  const { data: paper, isLoading, isError } = usePaper(paperId);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-12 flex justify-center items-center h-[60vh]">
          <div className="animate-pulse flex flex-col items-center">
            <div className="w-16 h-16 bg-muted rounded-full mb-4"></div>
            <div className="h-6 w-48 bg-muted rounded mb-2"></div>
            <div className="h-4 w-32 bg-muted/60 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (isError || !paper) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-serif font-bold text-foreground mb-4">Paper Not Found</h2>
          <p className="text-muted-foreground mb-8">The paper you're looking for doesn't exist or an error occurred.</p>
          <Link href="/dashboard">
            <button className="px-6 py-2 rounded-full bg-primary text-primary-foreground font-medium">
              Back to Dashboard
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      {/* Header Banner */}
      <div className="bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors mb-6">
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Link>
          
          <div className="flex flex-col lg:flex-row justify-between gap-8 items-start lg:items-center">
            <div className="flex-1 max-w-4xl">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-2.5 py-1 bg-white border border-border rounded-md text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-1.5 shadow-sm">
                  <FileText className="w-3.5 h-3.5" />
                  Analysis Report
                </span>
                {paper.createdAt && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium">
                    <Calendar className="w-3.5 h-3.5" />
                    {format(new Date(paper.createdAt), 'MMMM d, yyyy')}
                  </span>
                )}
              </div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold text-foreground leading-tight tracking-tight">
                {paper.title}
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="px-5 py-2.5 bg-white border-2 border-border rounded-full text-sm font-semibold text-foreground hover:bg-muted/50 transition-colors flex items-center gap-2 shadow-sm hidden sm:flex">
                <Download className="w-4 h-4" /> Export PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Score Card */}
          <div className="col-span-1 bg-card rounded-3xl p-8 border border-border shadow-sm flex flex-col items-center justify-center text-center">
            <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-8">Overall Integrity</h3>
            <ScoreBadge score={paper.integrityScore || 0} size="lg" />
            <p className="mt-8 text-sm text-muted-foreground max-w-[250px] leading-relaxed">
              Based on existence, context accuracy, and structural necessity of extracted citations.
            </p>
          </div>

          {/* Chart Card */}
          <div className="col-span-1 lg:col-span-2 bg-card rounded-3xl p-8 border border-border shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Citation Breakdown</h3>
              <span className="text-xs font-medium bg-muted px-2.5 py-1 rounded-md text-foreground">
                {paper.citations?.length || 0} Total References
              </span>
            </div>
            <div className="flex items-center justify-center">
              <CitationChart citations={paper.citations || []} />
            </div>
          </div>
        </div>

        {/* Detailed Table */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-serif font-bold text-foreground">Detailed Verification</h2>
          </div>
          <CitationTable citations={paper.citations || []} />
        </div>
      </main>
    </div>
  );
}
