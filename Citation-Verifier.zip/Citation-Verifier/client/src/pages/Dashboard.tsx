import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { Plus, FileText, ArrowRight, AlertCircle, RefreshCw } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { UploadDialog } from "@/components/papers/UploadDialog";
import { usePapers } from "@/hooks/use-papers";
import { ScoreBadge } from "@/components/papers/ScoreBadge";

export function Dashboard() {
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const { data: papers, isLoading, isError, refetch } = usePapers();

  return (
    <div className="min-h-screen bg-muted/10">
      <Navbar />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-6">
          <div>
            <h1 className="font-serif text-3xl font-bold text-foreground mb-2">My Papers</h1>
            <p className="text-muted-foreground">Manage and review your verified academic texts.</p>
          </div>
          <button 
            onClick={() => setIsUploadOpen(true)}
            className="px-6 py-3 rounded-xl font-semibold bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Verify New Paper
          </button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-card rounded-2xl p-6 border border-border shadow-sm h-48 animate-pulse flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="h-6 bg-muted rounded-md w-3/4"></div>
                  <div className="h-4 bg-muted rounded-md w-1/2"></div>
                </div>
                <div className="flex justify-between items-end">
                  <div className="h-12 w-12 bg-muted rounded-full"></div>
                  <div className="h-8 w-24 bg-muted rounded-full"></div>
                </div>
              </div>
            ))}
          </div>
        ) : isError ? (
          <div className="p-12 text-center bg-card rounded-2xl border border-destructive/20 shadow-sm flex flex-col items-center">
            <AlertCircle className="w-12 h-12 text-destructive mb-4" />
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">Failed to load papers</h3>
            <p className="text-muted-foreground mb-6">There was an error communicating with the server.</p>
            <button onClick={() => refetch()} className="flex items-center gap-2 px-5 py-2.5 bg-muted rounded-full hover:bg-muted/80 font-medium transition-colors">
              <RefreshCw className="w-4 h-4" /> Try Again
            </button>
          </div>
        ) : !papers || papers.length === 0 ? (
          <div className="p-16 text-center bg-card rounded-3xl border border-dashed border-border shadow-sm flex flex-col items-center">
            <div className="w-20 h-20 bg-primary/5 rounded-full flex items-center justify-center mb-6">
              <FileText className="w-10 h-10 text-primary/40" />
            </div>
            <h3 className="text-2xl font-serif font-bold text-foreground mb-3">No papers yet</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-8">
              You haven't uploaded any papers for verification. Click the button below to start analyzing your first text.
            </p>
            <button 
              onClick={() => setIsUploadOpen(true)}
              className="px-6 py-3 rounded-full font-semibold bg-white border-2 border-border text-foreground hover:bg-muted/50 transition-colors flex items-center gap-2"
            >
              Upload your first paper
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {papers.map((paper) => (
              <Link key={paper.id} href={`/paper/${paper.id}`}>
                <div className="bg-card group rounded-3xl p-6 border border-border shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 h-full flex flex-col cursor-pointer">
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <h3 className="font-serif text-xl font-bold text-foreground line-clamp-2 leading-tight group-hover:text-primary transition-colors">
                        {paper.title}
                      </h3>
                    </div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-6">
                      {paper.createdAt ? format(new Date(paper.createdAt), 'MMM d, yyyy') : 'Recently'}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between mt-auto pt-6 border-t border-border/50">
                    <div className="flex items-center gap-3">
                      <ScoreBadge score={paper.integrityScore || 0} size="sm" />
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Integrity</span>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-white" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>

      <UploadDialog open={isUploadOpen} onOpenChange={setIsUploadOpen} />
    </div>
  );
}
