import { Link } from "wouter";
import { motion } from "framer-motion";
import { ShieldCheck, FileSearch, PieChart, ArrowRight, Upload } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";

export function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[1200px] h-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px]" />
          <div className="absolute top-[20%] right-[-10%] w-[400px] h-[400px] bg-secondary/10 rounded-full blur-[80px]" />
        </div>

        <div className="max-w-4xl mx-auto text-center z-10 py-20 sm:py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary font-medium text-sm mb-8 border border-primary/20 shadow-sm">
              <ShieldCheck className="w-4 h-4" />
              <span>AI-Powered Academic Verification</span>
            </div>
            
            <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl font-bold text-foreground leading-[1.1] tracking-tight mb-6">
              Trust the Research. <br className="hidden sm:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">Verify the Citations.</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-10 text-balance">
              ScholarTrust automatically extracts, cross-references, and analyzes every citation in your paper to detect hallucinated references and weak contextual support.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/dashboard">
                <button className="w-full sm:w-auto px-8 py-4 rounded-full font-semibold bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 group">
                  <Upload className="w-5 h-5" />
                  Upload a Paper
                </button>
              </Link>
              <Link href="/dashboard">
                <button className="w-full sm:w-auto px-8 py-4 rounded-full font-semibold bg-white text-foreground border-2 border-border hover:border-primary/30 hover:bg-muted/30 transition-all duration-300 flex items-center justify-center gap-2">
                  View Dashboard
                  <ArrowRight className="w-4 h-4" />
                </button>
              </Link>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8"
          >
            {/* Feature 1 */}
            <div className="bg-card/50 backdrop-blur-sm p-8 rounded-3xl border border-border/60 shadow-sm text-left hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-6">
                <FileSearch className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-bold text-foreground mb-3">Deep Extraction</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Our algorithm isolates claims and their paired citations, preparing them for rigorous contextual validation.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-card/50 backdrop-blur-sm p-8 rounded-3xl border border-border/60 shadow-sm text-left hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6">
                <ShieldCheck className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="font-serif text-xl font-bold text-foreground mb-3">Crossref Validation</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Instantly check citation existence against the global Crossref database to eliminate hallucinated sources.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-card/50 backdrop-blur-sm p-8 rounded-3xl border border-border/60 shadow-sm text-left hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-secondary/10 rounded-2xl flex items-center justify-center mb-6">
                <PieChart className="w-6 h-6 text-secondary-foreground" />
              </div>
              <h3 className="font-serif text-xl font-bold text-foreground mb-3">Integrity Scoring</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Receive a comprehensive 0-100 Integrity Score reflecting accuracy, existence, and necessity metrics.
              </p>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
