import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type UploadPaperRequest, type PaperResponse } from "@shared/routes";

// Utility to parse and log validation errors
function parseWithLogging<T>(schema: any, data: unknown, label: string): T {
  if (data === null) return null as T;
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw new Error("Invalid data format received from server");
  }
  return result.data;
}

export function usePapers() {
  return useQuery({
    queryKey: [api.papers.list.path],
    queryFn: async () => {
      const res = await fetch(api.papers.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch papers");
      const data = await res.json();
      return parseWithLogging<PaperResponse[]>(api.papers.list.responses[200], data, "papers.list");
    },
  });
}

export function usePaper(id: number | string) {
  return useQuery({
    queryKey: [api.papers.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.papers.get.path, { id: id.toString() });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch paper");
      const data = await res.json();
      return parseWithLogging<PaperResponse>(api.papers.get.responses[200], data, "papers.get");
    },
    enabled: !!id,
  });
}

export function useUploadPaper() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: UploadPaperRequest) => {
      const validated = api.papers.upload.input.parse(data);
      const res = await fetch(api.papers.upload.path, {
        method: api.papers.upload.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to upload and analyze paper");
      }
      
      const responseData = await res.json();
      return parseWithLogging<PaperResponse>(api.papers.upload.responses[201], responseData, "papers.upload");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.papers.list.path] });
    },
  });
}
