import { db } from "./db";
import {
  papers,
  citations,
  users,
  type InsertPaper,
  type InsertCitation,
  type User,
} from "@shared/schema";
import { eq } from "drizzle-orm";
import type { PaperResponse } from "@shared/routes";

export interface IStorage {
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: any): Promise<User>;
  getPapers(userId?: number): Promise<PaperResponse[]>;
  getPaper(id: number): Promise<PaperResponse | undefined>;
  createPaper(paper: InsertPaper & { userId?: number }): Promise<PaperResponse>;
  createCitation(citation: InsertCitation): Promise<typeof citations.$inferSelect>;
  updatePaperIntegrity(id: number, score: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: any): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getPapers(userId?: number): Promise<PaperResponse[]> {
    let query = db.select().from(papers);
    if (userId) {
      // @ts-ignore
      query = query.where(eq(papers.userId, userId));
    }
    const allPapers = await query;
    const result: PaperResponse[] = [];
    for (const paper of allPapers) {
      const paperCitations = await db
        .select()
        .from(citations)
        .where(eq(citations.paperId, paper.id));
      result.push({ ...paper, citations: paperCitations });
    }
    return result;
  }

  async getPaper(id: number): Promise<PaperResponse | undefined> {
    const [paper] = await db.select().from(papers).where(eq(papers.id, id));
    if (!paper) return undefined;

    const paperCitations = await db
      .select()
      .from(citations)
      .where(eq(citations.paperId, id));

    return { ...paper, citations: paperCitations };
  }

  async createPaper(insertPaper: InsertPaper): Promise<PaperResponse> {
    const [paper] = await db.insert(papers).values(insertPaper).returning();
    return { ...paper, citations: [] };
  }

  async createCitation(insertCitation: InsertCitation) {
    const [citation] = await db
      .insert(citations)
      .values(insertCitation)
      .returning();
    return citation;
  }

  async updatePaperIntegrity(id: number, score: number): Promise<void> {
    await db
      .update(papers)
      .set({ integrityScore: score })
      .where(eq(papers.id, id));
  }
}

export const storage = new DatabaseStorage();