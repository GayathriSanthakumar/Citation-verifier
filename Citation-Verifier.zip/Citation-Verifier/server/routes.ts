import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { openai } from "./replit_integrations/image/client"; // reusing the openai client from image integration just for API keys, or import from ai integrations if available

// Simple regex to find things that look like citations e.g., [1] or (Smith, 2020)
function extractCitations(text: string): string[] {
  const matches = text.match(/\[\d+\]|\([A-Za-z]+ et al\., \d{4}\)|\([A-Za-z]+, \d{4}\)/g);
  return matches ? Array.from(new Set(matches)) : [];
}

async function verifyCitation(citation: string, textContext: string) {
  // 1. Check Crossref API (mock search for existence)
  let existenceScore = 0;
  try {
    const query = encodeURIComponent(citation.replace(/\[|\]|\(|\)/g, ''));
    const response = await fetch(`https://api.crossref.org/works?query=${query}&rows=1`);
    if (response.ok) {
      const data = await response.json();
      if (data.message.items && data.message.items.length > 0) {
        existenceScore = 100;
      } else {
        existenceScore = 20; // Some small score if not found directly
      }
    }
  } catch (e) {
    existenceScore = 50; // default if API fails
  }

  // 2. Use OpenAI to analyze accuracy and necessity based on context
  let accuracyScore = 0;
  let necessityScore = 0;
  let classification = "Padding";

  try {
    const prompt = `Analyze this citation context: "${textContext}"
    Citation marker: ${citation}
    Assume the citation exists.
    Rate its accuracy (0-100), necessity (0-100) and classify as one of: [Verified, Weak Support, Hallucinated, Padding].
    Respond ONLY in JSON format: {"accuracy": number, "necessity": number, "classification": "string"}`;
    
    const aiResponse = await openai.chat.completions.create({
      model: "gpt-4o-mini", // fallback to a simple model, or gpt-5.1 if required. Replit AI integrations supports standard models
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const resultText = aiResponse.choices[0]?.message?.content;
    if (resultText) {
      const parsed = JSON.parse(resultText);
      accuracyScore = parsed.accuracy || 50;
      necessityScore = parsed.necessity || 50;
      classification = parsed.classification || "Padding";
    }
  } catch (e) {
    console.error("AI check failed", e);
    accuracyScore = 60;
    necessityScore = 50;
    classification = "Weak Support";
  }

  return { existenceScore, accuracyScore, necessityScore, classification };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.auth.register.path, async (req, res) => {
    const input = api.auth.register.input.parse(req.body);
    const user = await storage.createUser(input);
    res.status(201).json({ id: user.id, username: user.username });
  });

  app.post(api.auth.login.path, async (req, res) => {
    const { username, password } = api.auth.login.input.parse(req.body);
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    res.json({ id: user.id, username: user.username, fullName: user.fullName });
  });
  
  app.get(api.papers.list.path, async (req, res) => {
    try {
      const papers = await storage.getPapers();
      res.json(papers);
    } catch (err) {
      res.status(500).json({ message: "Failed to list papers" });
    }
  });

  app.get(api.papers.get.path, async (req, res) => {
    try {
      const paper = await storage.getPaper(Number(req.params.id));
      if (!paper) {
        return res.status(404).json({ message: "Paper not found" });
      }
      res.json(paper);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.papers.upload.path, async (req, res) => {
    try {
      const input = api.papers.upload.input.parse(req.body);
      
      // Extract citations
      const extractedCitations = extractCitations(input.content);
      
      // If no citations found, just save
      if (extractedCitations.length === 0) {
        const paper = await storage.createPaper({ title: input.title, content: input.content });
        // Set integrity to 100 if no citations are even needed? Or 0. Let's say 100 for simplicity or NA.
        await storage.updatePaperIntegrity(paper.id, 0); 
        return res.status(201).json({ ...paper, citations: [] });
      }

      // Create paper
      const paper = await storage.createPaper({ title: input.title, content: input.content });

      let totalExistence = 0;
      let totalAccuracy = 0;
      let totalNecessity = 0;
      const citationResults = [];

      // Process each citation
      // Take a snippet of text around the citation for context
      for (const citation of extractedCitations) {
        const idx = input.content.indexOf(citation);
        const start = Math.max(0, idx - 100);
        const end = Math.min(input.content.length, idx + 100);
        const context = input.content.substring(start, end);

        const analysis = await verifyCitation(citation, context);
        
        const createdCitation = await storage.createCitation({
          paperId: paper.id,
          text: citation,
          existenceScore: analysis.existenceScore,
          accuracyScore: analysis.accuracyScore,
          necessityScore: analysis.necessityScore,
          classification: analysis.classification
        });

        citationResults.push(createdCitation);
        totalExistence += analysis.existenceScore;
        totalAccuracy += analysis.accuracyScore;
        totalNecessity += analysis.necessityScore;
      }

      // Calculate overall integrity score
      // Scoring Logic: 40% existence, 40% accuracy, 20% necessity
      const avgE = totalExistence / extractedCitations.length;
      const avgA = totalAccuracy / extractedCitations.length;
      const avgN = totalNecessity / extractedCitations.length;

      const integrityScore = Math.round((avgE * 0.4) + (avgA * 0.4) + (avgN * 0.2));
      
      await storage.updatePaperIntegrity(paper.id, integrityScore);
      
      const updatedPaper = await storage.getPaper(paper.id);
      res.status(201).json(updatedPaper);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error(err);
      res.status(500).json({ message: "Failed to upload and process paper" });
    }
  });

  return httpServer;
}
