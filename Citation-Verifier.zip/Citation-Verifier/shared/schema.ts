import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  fullName: text("full_name").notNull(),
  password: text("password").notNull(),
  role: text("role").notNull(), // researcher, student, professor
  createdAt: timestamp("created_at").defaultNow(),
});

export const papers = pgTable("papers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  integrityScore: integer("integrity_score"), // 0-100
  createdAt: timestamp("created_at").defaultNow(),
});

export const citations = pgTable("citations", {
  id: serial("id").primaryKey(),
  paperId: integer("paper_id").notNull().references(() => papers.id, { onDelete: 'cascade' }),
  text: text("text").notNull(),
  existenceScore: integer("existence_score").notNull(),
  accuracyScore: integer("accuracy_score").notNull(),
  necessityScore: integer("necessity_score").notNull(),
  classification: text("classification").notNull(), // Verified, Weak Support, Hallucinated, Padding
});

export const insertPaperSchema = createInsertSchema(papers).omit({ id: true, createdAt: true, integrityScore: true });
export const insertCitationSchema = createInsertSchema(citations).omit({ id: true });

export type Paper = typeof papers.$inferSelect;
export type InsertPaper = z.infer<typeof insertPaperSchema>;
export type Citation = typeof citations.$inferSelect;
export type InsertCitation = z.infer<typeof insertCitationSchema>;

export type CitationResponse = Citation;
export type PaperResponse = Paper & { citations: CitationResponse[] };

export type UploadPaperRequest = {
  title: string;
  content: string;
};