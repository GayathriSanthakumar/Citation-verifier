import { z } from "zod";
import { insertPaperSchema, papers, citations } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const citationSchema = z.custom<typeof citations.$inferSelect>();
const paperWithCitationsSchema = z.custom<typeof papers.$inferSelect>().and(z.object({ citations: z.array(citationSchema) }));

export const api = {
  auth: {
    register: {
      method: "POST" as const,
      path: "/api/register" as const,
      input: z.object({
        username: z.string().email(),
        password: z.string().min(6),
        fullName: z.string().min(2),
        role: z.string(),
      }),
      responses: {
        201: z.object({ id: z.number(), username: z.string() }),
        400: errorSchemas.validation,
      },
    },
    login: {
      method: "POST" as const,
      path: "/api/login" as const,
      input: z.object({
        username: z.string().email(),
        password: z.string(),
      }),
      responses: {
        200: z.object({ id: z.number(), username: z.string(), fullName: z.string() }),
        401: z.object({ message: z.string() }),
      },
    },
  },
  papers: {
    list: {
      method: "GET" as const,
      path: "/api/papers" as const,
      responses: {
        200: z.array(paperWithCitationsSchema),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/papers/:id" as const,
      responses: {
        200: paperWithCitationsSchema,
        404: errorSchemas.notFound,
      },
    },
    upload: {
      method: "POST" as const,
      path: "/api/papers" as const,
      input: z.object({
        title: z.string(),
        content: z.string(),
      }),
      responses: {
        201: paperWithCitationsSchema,
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type PaperResponse = z.infer<typeof paperWithCitationsSchema>;
export type UploadPaperRequest = z.infer<typeof api.papers.upload.input>;
